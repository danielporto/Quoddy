eventTestPhasesStart = {
	if (grailsAppName == 'grails-jms') {
		it.remove('functional')
	}
}